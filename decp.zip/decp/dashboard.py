# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 09:16:20 2020

@author: Administrator
"""
###############################################################################
import pickle
import os
chemin = "H:/Desktop/MEF_dep/decp-augmente/.gitignore"
os.chdir(chemin)
with open("test.pickle", "rb") as f:
     Bilan= pickle.load(f)
     Z= pickle.load(f)
     df= pickle.load(f)
     df_50= pickle.load(f)
     df_Classement= pickle.load(f)
     df_Dep= pickle.load(f)
     df_ERROR= pickle.load(f)
     df_RECAP= pickle.load(f)
     df_Reg= pickle.load(f)
     df_bar= pickle.load(f)
     df_carte= pickle.load(f)
     df_decp= pickle.load(f)
     df_ratio= pickle.load(f)
     df_ratio_entreprises= pickle.load(f)
     df_ratio_marche = pickle.load(f)
###############################################################################

import pandas as pd
from math import pi
from wordcloud import WordCloud


from bokeh.io import output_file, show
from bokeh.plotting  import gridplot
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum
from bokeh.models.widgets import Div

output_file("DB1.html")

### Pie chart des sources
source = pd.DataFrame(round(df_decp.source.value_counts(normalize=True)*100,2)).reset_index()
source['angle'] = source['source']/source['source'].sum() * 2*pi
source['color'] = ['#FD8E75','#FDDC75','#75FDA8','#7595FD','#DA75FD']

p = figure(width=480, height=300, title="Provenance des données en pourcentage", toolbar_location=None,
           tools="hover", tooltips="@source", x_range=(-0.5, 1.0), background_fill_color="#fafafa")
p.wedge(x=0, y=1, radius=0.35, start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
        line_color="white", fill_color='color', legend_field='index', source=source)
p.axis.axis_label=None
p.axis.visible=False
p.grid.grid_line_color = None


### Barplot de la nature des marchés
natureMarche = pd.DataFrame(round(df_decp.nature.value_counts(),2)).reset_index()
autre = pd.DataFrame([['AUTRE', natureMarche.nature[3:].sum()]], columns=['index','nature'])
natureMarche = pd.concat([natureMarche.head(3),autre])
natureMarche.reset_index(inplace=True, drop=True)
natureMarche.columns = ['index', 'nb']

n = figure(width=480, height=300, title="Nature des marchés", toolbar_location=None,
           x_range=natureMarche['index'], tools="", tooltips='@nb', background_fill_color="#fafafa")
n.vbar(x=natureMarche['index'], top=natureMarche['nb'], width=0.9, color=Category20c[len(natureMarche.nb)])
n.xgrid.grid_line_color = None
n.y_range.start = 0


### Lines des montants totaux par mois par ans
notification = df_decp.groupby(['anneeNotification', 'moisNotification']).moisNotification.count().to_frame('nb').reset_index()
notification = notification[(notification.anneeNotification!='nan') | (notification.moisNotification!='nan')]
notification = notification[(notification['anneeNotification']!='2012')] 
notification = notification[(notification['anneeNotification']!='2013')]  
notification = notification[(notification['anneeNotification']!='2014')]  
notification = notification[(notification['anneeNotification']!='2015')]  
notification = notification[(notification['anneeNotification']!='2016')]  
notification.moisNotification = notification.moisNotification.astype(int)
notification.anneeNotification = notification.anneeNotification.astype(int)
notification = pd.pivot_table(notification, values='nb', index='moisNotification', columns=['anneeNotification'])

numlines=len(notification.columns)
mypalette=Category20c[numlines]

notif = figure(width=480, height=300, x_axis_type="datetime", title="Notification des marchés par année", background_fill_color="#fafafa") 
notif.multi_line(xs=[notification.index.values]*numlines,
                ys=[notification[name].values for name in notification],
                line_color=mypalette, line_width=5)

formeMarche = pd.DataFrame(round(df_decp.formePrix.value_counts(),2)).reset_index()
typeMarche = pd.DataFrame(round(df_decp.type.value_counts(),2)).reset_index()
procedureMarche = pd.DataFrame(round(df_decp.procedure.value_counts(),2)).reset_index()


### Création d"un nuage de mots
a=pd.DataFrame(df_decp.referenceCPV)
a = pd.DataFrame(a['referenceCPV'].astype(str).apply(lambda x: x.split()))
a = pd.DataFrame(a.referenceCPV.explode())
a = a[a.referenceCPV!='nan']
a['referenceCPV']=a['referenceCPV'].str.upper()
a=a.loc[(a['referenceCPV'].str.len() > 3)]
for i in ["\\t","-"," ",".","?","    ", "D'", "L'", ',', '_', '(', ')']: 
    a.referenceCPV =  a.referenceCPV.astype(str).str.replace(i, "")
a.reset_index(inplace=True, drop=True)
resA = pd.DataFrame(round(a.referenceCPV.value_counts(),2)).reset_index()
wocl = resA['index'].head(30)
text = wocl.str.cat(sep = ' ')

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="#fafafa").generate(text)
wordcloud.to_file('wordcloud.png')
div_image = Div(text="""<p style="margin-top:5px; margin-left:30px; font-family: Helvetica, Arial ; font-size:13px"><b>Nuage de mots des références des marchés</b></p><img style="height:250px; width:440px; margin-left:15px;" src="wordcloud.png" alt="div_image">""")

# show the results
sortie = gridplot([[p, div_image], [n, notif]])
show(sortie)

###############################################################################

def split_int(number, separator=' ', count=3):
    return separator.join(
        [str(number)[::-1][i:i+count] for i in range(0, len(str(number)), count)]
    )[::-1]

output_file("NB1.html")

template=("""<div onmouseover="this.style.background='#E7F6FE';this.style.color='#000000';" onmouseout="this.style.background='{colour}';this.style.color='';"
          style="height:200px; width:200px; border: 2px solid #959595; border-radius:10px 10px 10px 10px; background-color: {colour};
          border-left:2px solid #959595">
                <div  style="height:40%; width:50%;padding:10px; margin-left: 10px;margin-top: 10px; border-bottom:1px solid #4d493e; font-size:15px; border-right:1px solid #4d493e;font-weight: bold;">{insertText1}</div>
                <div style="height:50%; width:90%;padding:10px; margin-top: 10px; margin-left: -5px; font-size:38px; color:#3182bd;"><center>{insertText2}</center></div>
            </div>""")

nb_contrats = len(df_decp)
nb_contrats=split_int(nb_contrats, ' ')
text1 = template.format(insertText1 = "Nombre de contrats", insertText2 = nb_contrats, colour='#d4e3eb')
div1 = Div(text=text1, style={})

nb_entreprises = df_decp.siretEtablissement.nunique()
nb_entreprises=split_int(nb_entreprises, ' ')
text2 = template.format(insertText1 = "Nombre d'entreprises distinctes", insertText2 = nb_entreprises, colour='#d4e3eb')
div2 = Div(text=text2, style={})


nb_concession = df_decp[df_decp.type=='Contrat de concession']
nb_concession = nb_concession[['type', 'identifiantMarche', 'montantOriginal', 'acheteurId']]
nb_concession = len(nb_concession.drop_duplicates(subset=['type', 'identifiantMarche', 'montantOriginal', 'acheteurId'], keep='first'))
nb_concession=split_int(nb_concession, ' ')
text3 = template.format(insertText1 = "Nombre de concessions", insertText2 = nb_concession, colour='#d4e3eb')
div3 = Div(text=text3, style={})



nb_titulaires = df_decp[df_decp.type=='Marché']
nb_titulaires = nb_titulaires[['type', 'identifiantMarche', 'montantOriginal', 'acheteurId']]
nb_titulaires = len(nb_titulaires.drop_duplicates(subset=['type', 'identifiantMarche', 'montantOriginal', 'acheteurId'], keep='first'))
nb_titulaires=split_int(nb_titulaires, ' ')
text4 = template.format(insertText1 = "Nombre de marchés", insertText2 = nb_titulaires, colour='#d4e3eb')
div4 = Div(text=text4, style={})

sortie = gridplot([[div1, div2], [div4, div3]], toolbar_options={'logo': None})
show(sortie)

###############################################################################
###############################################################################
###############################################################################
# Iframe DB2 = carte
###############################################################################

output_file("NB2.html")

nbVilles_Carte = len(df_carte)
nbVilles_Carte=split_int(nbVilles_Carte, ' ')
text1 = template.format(insertText1 = "Nombre de villes géolocalisées", insertText2 = nbVilles_Carte, colour='#d4e3eb')
div1 = Div(text=text1, style={})

distanceMoyenneVille = round(df_carte.distanceMediane.mean(),0).astype(int)
distanceMoyenneVille=split_int(distanceMoyenneVille, ' ')
text2 = template.format(insertText1 = "Distance moyenne avec les entreprises", insertText2 = distanceMoyenneVille + ' km', colour='#d4e3eb')
div2 = Div(text=text2, style={})

RegMontantMoyen = round(df_Reg.montant.mean(),0).astype(int)
RegMontantMoyen=split_int(RegMontantMoyen, ' ')
text3 = template.format(insertText1 = "Montant moyen par région", insertText2 = RegMontantMoyen + ' M€', colour='#d4e3eb')
div3 = Div(text=text3, style={})

dREG = pd.DataFrame(df_decp.regionAcheteur)
dREG.reset_index(inplace=True)
dREG=dREG.groupby(['regionAcheteur']).index.count().to_frame('count').sort_values(by = 'count', ascending = False)
regionMax = dREG.index[0]
text4 = template.format(insertText1 = "Région la plus représentée", insertText2 = '<a style="font-size:15px !important;">' + regionMax + '</a>', colour='#d4e3eb')
div4 = Div(text=text4, style={})

sortie = gridplot([[div1, div2], [div3, div4]], toolbar_options={'logo': None})
show(sortie)


# Région et département le plus représenté

###############################################################################
###############################################################################
###############################################################################

output_file("DB3.html")
# Montant / Durée
montantDuree = pd.DataFrame(df_decp.groupby('dureeMoisCalculee')['montant'].mean())
montantDuree = montantDuree[montantDuree.index <120]
montantDuree.reset_index(inplace=True)
montantDuree.dureeMoisCalculee=montantDuree.dureeMoisCalculee.astype(int).astype(str)

md = figure(width=800, height=275, title="Montant en fonction de la durée", background_fill_color="#fafafa")
md.line(montantDuree['dureeMoisCalculee'], montantDuree['montant'], line_width=2, line_color='#3182bd', legend='Montant')
md.xaxis.axis_label = 'Durée des marchés'
md.yaxis.axis_label = 'Montant des marchés'

# Graph par région
boxplotMontantRegion=pd.DataFrame(df_decp.groupby('regionAcheteur')['montant'].mean())
boxplotMontantRegion.reset_index(inplace=True)
boxplotMontantRegion.sort_values(by = 'montant', ascending = False, inplace=True)

bmr = figure(width=800, height=375, title="Montant par région", toolbar_location=None,
           x_range=boxplotMontantRegion['regionAcheteur'], background_fill_color="#fafafa")

bmr.vbar(x=boxplotMontantRegion['regionAcheteur'], top=boxplotMontantRegion['montant'], width=0.9, color=Category20c[len(boxplotMontantRegion)])
bmr.xaxis.major_label_orientation = 0.8
bmr.xgrid.grid_line_color = None
bmr.y_range.start = 0
bmr.yaxis.axis_label = 'Montant moyen'


sortie = gridplot([[md],[bmr],])
show(sortie)



###############################################################################

output_file("NB3.html")

montantMoyenMarche = round(df_decp.montant.mean(),0).astype(int)
montantMoyenMarche=split_int(montantMoyenMarche, ' ')
text1 = template.format(insertText1 = "Montant moyen par contrat", insertText2 = montantMoyenMarche + ' €', colour='#d4e3eb')
div1 = Div(text=text1, style={})

montantMoyenMarche = round(df_decp.montant.median(),0).astype(int)
montantMoyenMarche=split_int(montantMoyenMarche, ' ')
text3 = template.format(insertText1 = "Montant median par contrat", insertText2 = montantMoyenMarche + ' €', colour='#d4e3eb')
div3 = Div(text=text3, style={})

dureeMoyenneMarche = round(df_decp.dureeMoisCalculee.mean(),0).astype(int)
dureeMoyenneMarche=split_int(dureeMoyenneMarche, ' ')
text2 = template.format(insertText1 = "Durée moyenne par contrat", insertText2 = dureeMoyenneMarche + ' mois', colour='#d4e3eb')
div2 = Div(text=text2, style={})

DepMontantMoyen = round(df_Dep.montant.mean(),0).astype(int)
DepMontantMoyen=split_int(DepMontantMoyen, ' ')
text4 = template.format(insertText1 = "Montant moyen par habitant", insertText2 = DepMontantMoyen + ' €', colour='#d4e3eb')
div4 = Div(text=text4, style={})

sortie = gridplot([[div1, div3], [div2, div4]], toolbar_options={'logo': None})
show(sortie)


###############################################################################
###############################################################################
###############################################################################

output_file("DB4.html")
source = pd.DataFrame(round(df_ERROR.source.value_counts(normalize=True)*100,2)).reset_index()
source['angle'] = source['source']/source['source'].sum() * 2*pi
source['color'] = ['#FD8E75','#FDDC75','#75FDA8','#7595FD','#DA75FD']

p = figure(width=460, height=300, title="Provenance des erreurs en pourcentage", toolbar_location=None,
           tools="hover", tooltips="@source", x_range=(-0.5, 1.0), background_fill_color="#fafafa")
p.wedge(x=0, y=1, radius=0.35, start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
        line_color="white", fill_color='color', legend_field='index', source=source)
p.axis.axis_label=None
p.axis.visible=False
p.grid.grid_line_color = None


pieBilan = pd.DataFrame(Bilan.T)
pieBilan.reset_index(inplace=True)
pieBilan = pd.DataFrame([tup[1] for tup in pieBilan.itertuples() for i in range(int(tup[2]))])
source = pd.DataFrame(round(pieBilan[0].value_counts(normalize=True)*100,2)).reset_index()
source=source.rename(columns = {0: 'source'})

source['angle'] = source['source']/source['source'].sum() * 2*pi
source['color'] = ['#FD8E75','#FDDC75','#75FDA8','#7595FD']
p2 = figure(width=460, height=300, title="Provenance des erreurs en pourcentage", toolbar_location=None,
           tools="hover", tooltips="@source", x_range=(-0.5, 1.0), background_fill_color="#fafafa")
p2.wedge(x=0, y=1, radius=0.35, start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
        line_color="white", fill_color='color', legend_field='index', source=source)
p2.axis.axis_label=None
p2.axis.visible=False
p2.grid.grid_line_color = None



df_ratioGraph = df_ratio.head(10)
bmr = figure(width=460, height=350, title="Ratio nb entreprises / nb marchés (>40K)", toolbar_location=None,
           x_range=df_ratioGraph['libelleCommuneAcheteur'], background_fill_color="#fafafa")

bmr.vbar(x=df_ratioGraph['libelleCommuneAcheteur'], top=df_ratioGraph['ratioEntreprisesMarchés'], width=0.9, color=Category20c[len(df_ratioGraph)])
bmr.xaxis.major_label_orientation = 0.8
bmr.xgrid.grid_line_color = None
bmr.y_range.start = 0
bmr.yaxis.axis_label = 'Ratio (Moyenne 0.9)'

df_ratioGraph = df_bar.head(10)
bmr2 = figure(width=460, height=350, title="Ratio nb entreprises / nb marchés", toolbar_location=None,
           x_range=df_ratioGraph['libelleCommuneAcheteur'], background_fill_color="#fafafa")

bmr2.vbar(x=df_ratioGraph['libelleCommuneAcheteur'], top=df_ratioGraph['ratioEntreprisesMarchés'], width=0.9, color=Category20c[len(df_ratioGraph)])
bmr2.xaxis.major_label_orientation = 0.8
bmr2.xgrid.grid_line_color = None
bmr2.y_range.start = 0
bmr2.yaxis.axis_label = 'Ratio (Moyenne 0.7)'

#, background_fill_color="#fafafa"
sortie = gridplot([[p, p2], [bmr2, bmr]])
show(sortie)

###############################################################################

output_file("NB4.html")

montantAberrant=round(Bilan['Montant aberrant '].iloc[0]/len(df_decp)*100,2).astype(str)
text1 = template.format(insertText1 = "Nombre de montants aberrants", insertText2 = montantAberrant + '%', colour='#d4e3eb')
div1 = Div(text=text1, style={})

dureeAberrante= round(Bilan['Durée en mois aberrante '].iloc[0]/len(df_decp)*100,2).astype(str)
text2 = template.format(insertText1 = "Nombre de durées aberrantes", insertText2 = dureeAberrante + '%', colour='#d4e3eb')
div2 = Div(text=text2, style={})

siretA_Faux=round(Bilan['Siret acheteur mauvais '].iloc[0]/len(df_decp)*100,2).astype(str)
text3 = template.format(insertText1 = "Nombre de siret acheteur incorrects", insertText2 = siretA_Faux + '%', colour='#d4e3eb')
div3 = Div(text=text3, style={})

siretE_Faux= round(Bilan['Siret entreprise mauvais '].iloc[0]/len(df_decp)*100,2).astype(str)
text4 = template.format(insertText1 = "Nombre de siret entreprise incorrects", insertText2 = siretE_Faux + '%', colour='#d4e3eb')
div4 = Div(text=text4, style={})

sortie = gridplot([[div1, div2], [div3, div4]], toolbar_options={'logo': None})
show(sortie)

