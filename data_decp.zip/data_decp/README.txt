Commande pour importer les données sur Python : 
(il faut rajouter chemin à la place des petits points)

###############################################################################################################
import pandas as pd

chemin = '.../decp.csv"
df_decp = pd.read_csv('H:/Desktop/Data/decp.csv', sep=';', encoding='utf-8',
                      dtype={'acheteur.id' : str, 'nic' : str, 'codeRegion' : str, 'denominationSociale' : str,
                             'moisNotification' : str,  'idTitulaires' : str, 'montant' : float, 'codePostal' : str,
                             'anneeNotification' : str, 'moisNotification' : str, 'codeCommuneEtablissement' : str,
                             'codePostalEtablissement' : str, 'codeTypeEtablissement' : str, 'siren' : str, 'siret' : str})
###############################################################################################################